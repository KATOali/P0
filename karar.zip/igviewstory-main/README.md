# Instagram Auto View Story
Instagram Auto View Story is an automation tool to view thousands of stories with in minutes without getting action block. 

## Features
- View Stories
  
## Uses 
- Increasing profile visits and followers
   
## Installation

Requires at least Python version 3+ to run.

Turn off Two-factor authentication (2FA).

```
$ git clone https://github.com/verssache/igviewstory
$ cd igviewstory
$ pip3 install -r requirements.txt
$ python3 login.py
$ python3 run.py
```

## Note
DWYOR (Do With Your Own Risk)

## Credits
Author credits : nthanfp
